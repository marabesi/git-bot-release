<?php

namespace Gitbot\Infrastructure\Income;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use GuzzleHttp\Psr7\Response;

class AuthHttp implements RequestHandlerInterface
{
    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        print_r( 23123123);
        $CLIENT_ID = '0e9b6f9218d87a8eb766c60f3f79b497e28b2ca207df15652a0f99fbe7f89a0e';
        $SECRET = '8174bfdb862fdd5a5874fd2e9301ee50d384894d6e2cd5b88df4e9cbfb598f8d';
        $REDIRECT_CODE = 'http://localhost:8181';
        $STATE = 'AIUSHIDHAISDHIASA12290120929012029aaaa';

        if ($_GET['error']) {
            // Array
            // (0e9b6f9218d87a8eb766c60f3f79b497e28b2ca207df15652a0f99fbe7f89a0e
            //     [error] => access_denied
            //     [error_description] => The resource owner or authorization server denied the request.
            //     [state] => AIUSHIDHAISDHIASA12290120929012029
            // )
            echo '<p>' . $_GET['error'] . '</p><a href="/">try again</a>';
            exit();
        }

        if ($_GET['code'] && $_GET['state']) {
            $outGoing = new NetworkRequest();
            $token = $outGoing->post('https://gitlab.com/oauth/token', [
                'client_id' => $CLIENT_ID,
                'client_secret' => $SECRET,
                'code' => $_GET['code'],
                'grant_type' => 'authorization_code',
                'redirect_uri' => $REDIRECT_CODE
            ]);

            // @todo review location
            file_put_contents('token.json', $token);
        }

        $generateCodeAndState = "https://gitlab.com/oauth/authorize?client_id=$CLIENT_ID&redirect_uri=$REDIRECT_CODE&response_type=code&state=$STATE&scope=read_repository+write_repository+api";

        return new Response(301, [
            'Location: ' . $generateCodeAndState
        ], 'Hello world!');
    }
}
