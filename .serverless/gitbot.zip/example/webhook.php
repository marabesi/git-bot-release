<?php

$token = 'GASJKLAS9183KASJDKA';

$projectId = '19762552';

$auth = json_decode(file_get_contents('token.json'), true);

$url = sprintf('https://gitlab.com/api/v4/projects/%s/hooks', $projectId);

$content = http_build_query([
    'url' => 'https://9f55d5fc89ad.ngrok.io/webhook.php',
    'token' => $token,
    'push_events' => true,
    'enable_ssl_verification' => true,
]);

//print_r($content);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $auth['access_token'],
]);
$result = curl_exec($ch);
$error = curl_error($ch);

if ($error) {
    throw new Exception($error);
}

echo $result;