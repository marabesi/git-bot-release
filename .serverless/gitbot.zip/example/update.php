<?php

$projectId = '19762552';

$auth = json_decode(file_get_contents('token.json'), true);

$url = sprintf('https://gitlab.com/api/v4/projects/%s/repository/files/%s', $projectId, 'README.md');
$content = json_encode(
        [
            'branch' => 'master',
            'content' => 'updated via api',
            'commit_message' => 'content updated via api'
        ]
    );

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
curl_setopt($ch,  CURLOPT_HTTPHEADER, array(
    'Authorization: Bearer ' . $auth['access_token'],
    "cache-control: no-cache",
    "content-type: application/json",
));

$result = curl_exec($ch);
$error = curl_error($ch);

if ($error) {
    throw new Exception($error);
}
echo $result;
exit();