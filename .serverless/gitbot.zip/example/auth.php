<?php

$CLIENT_ID = '0e9b6f9218d87a8eb766c60f3f79b497e28b2ca207df15652a0f99fbe7f89a0e';
$SECRET = '8174bfdb862fdd5a5874fd2e9301ee50d384894d6e2cd5b88df4e9cbfb598f8d';
$REDIRECT_CODE = 'http://localhost:8181';
$STATE = 'AIUSHIDHAISDHIASA12290120929012029aaaa';

if ($_GET['error']) {
    // Array
    // (0e9b6f9218d87a8eb766c60f3f79b497e28b2ca207df15652a0f99fbe7f89a0e
    //     [error] => access_denied
    //     [error_description] => The resource owner or authorization server denied the request.
    //     [state] => AIUSHIDHAISDHIASA12290120929012029
    // )
    echo '<p>' . $_GET['error'] . '</p><a href="/">try again</a>';
    exit();
}

if ($_GET['code'] && $_GET['state']) {
    $code = $_GET['code'];
    $state = $_GET['state'];

    $generateToken = 'https://gitlab.com/oauth/token';
    $content = http_build_query(
        [
            'client_id' => $CLIENT_ID,
            'client_secret' => $SECRET,
            'code' => $code,
            'grant_type' => 'authorization_code',
            'redirect_uri' => $REDIRECT_CODE
        ]
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $generateToken);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($ch);

    file_put_contents('token.json', $result);
    header('Location: authorized.php');
    exit;
}

$generateCodeAndState = "https://gitlab.com/oauth/authorize?client_id=$CLIENT_ID&redirect_uri=$REDIRECT_CODE&response_type=code&state=$STATE&scope=read_repository+write_repository+api";

header('Location: ' . $generateCodeAndState);
exit();